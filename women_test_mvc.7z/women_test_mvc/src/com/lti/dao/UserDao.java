package com.lti.dao;

import java.util.List;

import com.lti.model.NgoDetails;
import com.lti.model.User;

public interface UserDao {

	public int readLoginAdmin(String username, String password);
	public int readLoginUser(String username, String password);
	public int createUser(User user);
	public int createNgo(NgoDetails ngoDetails);
	public List<NgoDetails> readAllNgos();
}
