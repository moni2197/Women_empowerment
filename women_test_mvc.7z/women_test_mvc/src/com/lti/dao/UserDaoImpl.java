package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lti.model.Admin;
import com.lti.model.NgoDetails;
import com.lti.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	private EntityManager entityManager;
	private String jpql;
	private User user;
	private NgoDetails ngoDetails;

	public UserDaoImpl() {
		super();
	}

	public int readLoginAdmin(String username, String password) {
		// String jpql = "Select u From Users u Where u.username='"+username+"'
		// And u.password='"+password+"'";

		jpql = "SELECT a from Admin a where a.username =:user AND a.password =:pass";
		TypedQuery<Admin> tquery = entityManager.createQuery(jpql, Admin.class);
		tquery.setParameter("user", username);
		tquery.setParameter("pass", password);
		List<Admin> list = tquery.getResultList();
		System.out.println(list.size());

		return list.size();
	}

	public int readLoginUser(String username, String password) {
		// String jpql = "Select u From Users u Where u.username='"+username+"'
		// And u.password='"+password+"'";
		jpql = "SELECT u from User u where u.username=:user AND u.password=:pass";
		TypedQuery<User> tquery = entityManager.createQuery(jpql, User.class);
		tquery.setParameter("user", username);
		tquery.setParameter("pass", password);
		List<User> list = tquery.getResultList();
		return list.size();
	}

	@Override
	public int createUser(User user) {
		entityManager.persist(user);
		user = entityManager.find(User.class, user.getUsername());
		if (user != null) {
			return 1;
		} else {
			return 0;
		}

	}

	@Override
	public int createNgo(NgoDetails ngoDetails) {
		entityManager.persist(ngoDetails);
		ngoDetails = entityManager.find(NgoDetails.class, ngoDetails.getNgoRegisterationId());
		if (ngoDetails != null) {
			return 1;
		} else {
			return 0;
		}
	}

	@Override
	public List<NgoDetails> readAllNgos() {
		String jpql="From NgoDetails";
		TypedQuery<NgoDetails> tquery=entityManager.createQuery(jpql,NgoDetails.class);
		List<NgoDetails>list=tquery.getResultList();
		return list;
	}

}
