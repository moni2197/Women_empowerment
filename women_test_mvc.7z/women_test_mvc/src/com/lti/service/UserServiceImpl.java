package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.UserDao;
import com.lti.model.NgoDetails;
import com.lti.model.User;

@Service("service")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;

	@Override
	public boolean checkLoginUser(String username, String password) {

		int result = getDao().readLoginUser(username, password);
		if (result == 1)
			return true;
		else
			return false;

	}

	@Override
	public boolean checkLoginAdmin(String username, String password) {
		System.out.println("i am in userservice");
		int result = getDao().readLoginAdmin(username, password);
		if (result >= 1)
			return true;
		else
			return false;
	}

	public UserDao getDao() {
		return dao;
	}

	public void setDao(UserDao dao) {
		this.dao = dao;
	}

	@Override
	@Transactional
	public boolean registerUser(User user) {
		int result=getDao().createUser(user);
		if(result==1)
			return true;
		else
			return false;
	}

	@Override
	public boolean registerNgo(NgoDetails ngoDetails) {
		int result=getDao().createNgo(ngoDetails);
		if(result==1)
			return true;
		else
			return false;
	}

	@Override
	public List<NgoDetails> findAllNgos() {
		List<NgoDetails>list=getDao().readAllNgos();
		return list;
	}

}
