package com.lti.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Entity
@Scope(scopeName = "prototype")
@Table(name = "ngo_details")
public class NgoDetails {
	@Id
	private long ngoRegisterationId;
	private String	organizationName;
	private String ownerName;
	private String state;
	private String city;
	private int zipCode;
	private String address;
	private String webSite;
	private int staffStrength;
	
	private String memorandumOfAssociation;
	private String societiesRegistrationAffidavit;
	
	@Column(name="Approval_status")
	private String approvalStatus;
	
	@OneToMany(mappedBy="ngo", cascade=CascadeType.ALL)
	private List<hostel_details>hostels=new ArrayList<>();
	
	@OneToOne
	@JoinColumn(name="username")
	private User user;

	public long getNgoRegisterationId() {
		return ngoRegisterationId;
	}

	public void setNgoRegisterationId(long ngoRegisterationId) {
		this.ngoRegisterationId = ngoRegisterationId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String owner) {
		this.ownerName = owner;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getWebSite() {
		return webSite;
	}

	public void setWebSite(String webSite) {
		this.webSite = webSite;
	}

	public int getStaffStrength() {
		return staffStrength;
	}

	public void setStaffStrength(int staffStrength) {
		this.staffStrength = staffStrength;
	}

	public String getMemorandumOfAssociation() {
		return memorandumOfAssociation;
	}

	public void setMemorandumOfAssociation(String memorandumOfAssociation) {
		this.memorandumOfAssociation = memorandumOfAssociation;
	}

	public String getSocietiesRegistrationAffidavit() {
		return societiesRegistrationAffidavit;
	}

	public void setSocietiesRegistrationAffidavit(String societiesRegistrationAffidavit) {
		this.societiesRegistrationAffidavit = societiesRegistrationAffidavit;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	@Override
	public String toString() {
		return "NgoDetails [ngoRegisterationId=" + ngoRegisterationId + ", organizationName=" + organizationName
				+ ", owner=" + ownerName + ", state=" + state + ", city=" + city + ", zipCode=" + zipCode + ", address="
				+ address + ", webSite=" + webSite + ", staffStrength=" + staffStrength + ", memorandumOfAssociation="
				+ memorandumOfAssociation + ", societiesRegistrationAffidavit=" + societiesRegistrationAffidavit
				+ ", approvalStatus=" + approvalStatus + "]";
	}

	public NgoDetails(long ngoRegisterationId, String organizationName, String owner, String state, String city,
			int zipCode, String address, String webSite, int staffStrength, String memorandumOfAssociation,
			String societiesRegistrationAffidavit, String approvalStatus) {
		super();
		this.ngoRegisterationId = ngoRegisterationId;
		this.organizationName = organizationName;
		this.ownerName = owner;
		this.state = state;
		this.city = city;
		this.zipCode = zipCode;
		this.address = address;
		this.webSite = webSite;
		this.staffStrength = staffStrength;
		this.memorandumOfAssociation = memorandumOfAssociation;
		this.societiesRegistrationAffidavit = societiesRegistrationAffidavit;
		this.approvalStatus = approvalStatus;
	}

	public NgoDetails() {
		super();
	}

	public List<hostel_details> getHostels() {
		return hostels;
	}

	public void setHostels(List<hostel_details> hostels) {
		this.hostels = hostels;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
	
}
