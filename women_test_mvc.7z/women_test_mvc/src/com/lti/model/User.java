package com.lti.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Entity
@Scope(scopeName="prototype")
@Table(name="user_details")
public class User {

	@Id
	private String username;
	private String password;
	private String first_name;
	private String middle_name;
	private String last_name;
	private String e_mail;
	private long contact_no;
	private Date date_of_birth;
	
	
	public User() {
		super();
	}
	public User(String username, String password, String first_name, String middle_name, String last_name,
			String e_mail, long contact_no, Date date_of_birth) {
		super();
		this.username = username;
		this.password = password;
		this.first_name = first_name;
		this.middle_name = middle_name;
		this.last_name = last_name;
		this.e_mail = e_mail;
		this.contact_no = contact_no;
		this.date_of_birth = date_of_birth;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getE_mail() {
		return e_mail;
	}
	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}
	public long getContact_no() {
		return contact_no;
	}
	public void setContact_no(long contact_no) {
		this.contact_no = contact_no;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", first_name=" + first_name + ", middle_name="
				+ middle_name + ", last_name=" + last_name + ", e_mail=" + e_mail + ", contact_no=" + contact_no
				+ ", date_of_birth=" + date_of_birth + "]";
	}
	
	
}
