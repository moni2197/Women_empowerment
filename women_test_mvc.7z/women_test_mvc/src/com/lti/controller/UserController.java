package com.lti.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.NgoDetails;
import com.lti.model.User;
import com.lti.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;
	@Autowired
	private User user;

	private NgoDetails ngoDetails;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String HomePage() {
		return "Home";
	}

	@RequestMapping(path = "viewAdminLoginPage")
	public String adminLoginPage() {
		return "adminLogin";
	}

	@RequestMapping(path = "adminlogin.do")
	public String verifyAdmin(@RequestParam("username") String username, @RequestParam("password") String password) {
		System.out.println(username + " " + password);
		boolean result = service.checkLoginAdmin(username, password);
		if (result)
			return "adminHome";
		else
			return "loginFailed";
	}

	@RequestMapping(path = "viewUserLoginPage")
	public String userLoginPage() {
		return "userLogin";
	}

	@RequestMapping(path = "userLogin.do")
	public String verifyUser(@RequestParam("username") String username, @RequestParam("password") String password) {
		System.out.println(username + " " + password);
		boolean result = service.checkLoginUser(username, password);
		if (result)
			return "loginSuccessful";
		else
			return "loginFailed";
	}

	@RequestMapping(path = "add")
	public String addUserPage() {
		return "userregistration";
	}

	@RequestMapping(path = "add.do")
	public String addUser(@RequestParam("username") String userName, @RequestParam("password") String password,
			@RequestParam("firstname") String firstName, @RequestParam("middlename") String middleName,
			@RequestParam("lastname") String lastName, @RequestParam("emailid") String email,
			@RequestParam("contactno") long contactNo, @RequestParam("dateofbirth") Date dateOfBirth) {
		user.setUsername(userName);
		user.setFirst_name(firstName);
		user.setMiddle_name(middleName);
		user.setPassword(password);
		user.setLast_name(lastName);
		user.setContact_no(contactNo);
		user.setDate_of_birth(dateOfBirth);
		user.setE_mail(email);
		service.registerUser(user);
		return "userlogin";
	}

	@RequestMapping(path = "ngoRegistrationPage")
	public String ngoRegistrationPage() {
		return "ngoregistration";
	}

	@RequestMapping(path = "ngoadd.do")
	public String addNgo(@RequestParam("ngoname") String ngoName, @RequestParam("ownername") String ownerName,
			@RequestParam("state") String state, @RequestParam("city") String city,
			@RequestParam("zipcode") int zipCode, @RequestParam("ngoaddress") String ngoAddress,
			@RequestParam("website") String webSite, @RequestParam("staffno") int staffStrength,
			@RequestParam("moa") String memorandumOfAssociation,
			@RequestParam("sra") String societiesRegistrationAffidavit) {
		ngoDetails.setOrganizationName(ngoName);
		ngoDetails.setOwnerName(ownerName);
		ngoDetails.setState(state);
		ngoDetails.setCity(city);
		ngoDetails.setZipCode(zipCode);
		ngoDetails.setAddress(ngoAddress);
		ngoDetails.setWebSite(webSite);
		ngoDetails.setStaffStrength(staffStrength);
		ngoDetails.setMemorandumOfAssociation(memorandumOfAssociation);
		ngoDetails.setSocietiesRegistrationAffidavit(societiesRegistrationAffidavit);
		ngoDetails.setApprovalStatus("pending");
		service.registerNgo(ngoDetails);
		return "home";
	}
	
	@RequestMapping(path="viewNgos.do")
	public String viewAllNgos(Model model)
	{
		List<NgoDetails>list=service.findAllNgos();
		model.addAttribute("ngoList",list);
		return "viewAllNgos";
	}

}
