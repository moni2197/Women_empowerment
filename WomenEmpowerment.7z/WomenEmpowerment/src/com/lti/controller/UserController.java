package com.lti.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.NgoDetails;
import com.lti.model.User;
import com.lti.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private User user;

	@Autowired
	private NgoDetails ngoDetails;

	private boolean result = false;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String HomePage() {
		return "homepage";
	}

	@RequestMapping(path = "viewAdminLoginPage")
	public String adminLoginPage() {
		return "adminlogin";
	}

	@RequestMapping(path = "adminlogin.do", method = RequestMethod.POST)
	public String verifyAdmin(@RequestParam("username") String username, @RequestParam("password") String password) {
		result = service.checkLoginAdmin(username, password);
		if (result)
			return "adminhomepage";
		else
			return "errorpage";
	}

	@RequestMapping(path = "viewUserLoginPage")
	public String userLoginPage() {
		return "userlogin";
	}

	@RequestMapping(path = "userLogin.do", method = RequestMethod.POST)
	public String verifyUser(@RequestParam("username") String username, @RequestParam("password") String password) {
		result = service.checkLoginUser(username, password);
		if (result)
			return "userhome";
		else
			return "homepage";
	}

	@RequestMapping(path = "viewUserRegistrationPage")
	public String addUserPage() {
		return "userregistration";
	}

	@RequestMapping(path = "add.do", method = RequestMethod.POST)
	public String addUser(@RequestParam("username") String userName, @RequestParam("password") String password,
			@RequestParam("firstname") String firstName, @RequestParam("middlename") String middleName,
			@RequestParam("lastname") String lastName, @RequestParam("emailid") String email,
			@RequestParam("contactno") long contactNo, @RequestParam("dateofbirth") String dateOfBirth) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			Date date = formatter.parse(dateOfBirth);
			user.setDate_of_birth(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		user.setUsername(userName);
		user.setFirst_name(firstName);
		user.setMiddle_name(middleName);
		user.setPassword(password);
		user.setLast_name(lastName);
		user.setContact_no(contactNo);
		user.setE_mail(email);
		result = service.registerUser(user);
		if (result) {
			service.send(email);
		} else {
			return "errorpage";
		}
		return "userlogin";
	}

	@RequestMapping(path = "ngoRegistrationPage")
	public String ngoRegistrationPage() {
		return "ngoregistration";
	}

	@RequestMapping(path = "ngoadd.do", method = RequestMethod.POST)
	public String addNgo(@RequestParam("ngoname") String ngoName, @RequestParam("ownername") String ownerName,
			@RequestParam("state") String state, @RequestParam("city") String city,
			@RequestParam("zipcode") int zipCode, @RequestParam("ngoaddress") String ngoAddress,
			@RequestParam("website") String webSite, @RequestParam("staffno") int staffStrength,
			@RequestParam("moa") String memorandumOfAssociation,
			@RequestParam("sra") String societiesRegistrationAffidavit, @RequestParam("username") String username) {
		ngoDetails.setOrganizationName(ngoName);
		ngoDetails.setOwnerName(ownerName);
		ngoDetails.setState(state);
		ngoDetails.setCity(city);
		ngoDetails.setZipCode(zipCode);
		ngoDetails.setAddress(ngoAddress);
		ngoDetails.setWebSite(webSite);
		ngoDetails.setStaffStrength(staffStrength);
		ngoDetails.setMemorandumOfAssociation(memorandumOfAssociation);
		ngoDetails.setSocietiesRegistrationAffidavit(societiesRegistrationAffidavit);
		ngoDetails.setApprovalStatus("pending");
		user.setUsername(username);
		ngoDetails.setUser(user);
		service.registerNgo(ngoDetails);
		return "homepage";
	}

	@RequestMapping(path = "viewNgos.do")
	public String viewAllNgos(Model model) {
		List<NgoDetails> list = service.findAllNgos();
		model.addAttribute("ngoList", list);
		return "viewallngos";
	}

	@RequestMapping(path = "updateNgo.do", method = RequestMethod.POST)
	public String updateNgo(@RequestParam("registrationId") long ngoRegisterationId,
			@RequestParam("approvalStatus") String approvalStatus) {
		result = service.modifyNgo(ngoRegisterationId, approvalStatus);
		if (result)

			return "redirect:viewNgos.do";
		else
			return "error";
	}

}
