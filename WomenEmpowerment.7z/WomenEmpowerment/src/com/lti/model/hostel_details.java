package com.lti.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Entity
@Scope(scopeName = "prototype")
@Table(name = "hostel_details")
public class hostel_details {

	@Id
	private String hostel_id;
	private String state;
	private String city;
	private String zip_code;
	private String address;
	private int capacity;
	
	
	@ManyToOne
	@JoinColumn(name="ngoRegisterationId")
	private NgoDetails ngo;
	
	
	
	public hostel_details(String hostel_id, String state, String city, String zip_code, String address, int capacity) {
		super();
		this.hostel_id = hostel_id;
		this.state = state;
		this.city = city;
		this.zip_code = zip_code;
		this.address = address;
		this.capacity = capacity;
	}
	public hostel_details() {
		super();
	}
	public String getHostel_id() {
		return hostel_id;
	}
	public void setHostel_id(String hostel_id) {
		this.hostel_id = hostel_id;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZip_code() {
		return zip_code;
	}
	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	@Override
	public String toString() {
		return "hostel_details [hostel_id=" + hostel_id + ", state=" + state + ", city=" + city + ", zip_code="
				+ zip_code + ", address=" + address + ", capacity=" + capacity + "]";
	}
	

	
	
	
	
}
